const projects = [
  {
    slug: "ci-cd-microservicios",
    title: "Pipeline CI/CD para microservicios",
    summary: "Automatización de build, pruebas y despliegue con GitHub Actions y Docker para un conjunto de microservicios.",
    tags: ["CI/CD", "GitHub Actions", "Docker"],
    type: "ci-cd",
    githubUrl: "https://github.com/youruser/ci-cd-microservices",
    codeSnippet: `name: ci-cd
on: [push]
jobs:
  build-test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'
      - run: npm ci && npm test
      - name: Build Docker
        run: docker build -t ghcr.io/youruser/app:$GITHUB_SHA .
      - name: Push Image
        run: echo $CR_PAT | docker login ghcr.io -u youruser --password-stdin
      - run: docker push ghcr.io/youruser/app:$GITHUB_SHA
  deploy:
    needs: build-test
    runs-on: ubuntu-latest
    steps:
      - name: Deploy to server
        uses: appleboy/ssh-action@v1.0.3
        with:
          host: ${{ secrets.HOST }}
          username: ${{ secrets.USERNAME }}
          key: ${{ secrets.SSH_KEY }}
          script: |
            docker pull ghcr.io/youruser/app:$GITHUB_SHA
            docker compose up -d`,
  },
  {
    slug: "iac-aws-terraform",
    title: "Infraestructura como Código en AWS con Terraform",
    summary: "Provisionamiento de VPC, subredes y EC2 con Terraform modular y backend remoto.",
    tags: ["Terraform", "AWS", "VPC"],
    type: "iac",
    githubUrl: "https://github.com/youruser/iac-aws-terraform",
    codeSnippet: `terraform {
  required_version = ">= 1.6.0"
  backend "s3" {
    bucket = "tf-state-youruser"
    key    = "prod/network.tfstate"
    region = "us-east-1"
  }
}

provider "aws" { region = "us-east-1" }

module "vpc" {
  source = "terraform-aws-modules/vpc/aws"
  name = "prod"
  cidr = "10.0.0.0/16"
  azs  = ["us-east-1a", "us-east-1b"]
  public_subnets  = ["10.0.1.0/24", "10.0.2.0/24"]
  private_subnets = ["10.0.3.0/24", "10.0.4.0/24"]
}`,
  },
  {
    slug: "observabilidad-grafana",
    title: "Observabilidad con Grafana",
    summary: "Dashboards de métricas y alertas para mejorar la disponibilidad (SLO 99.9%).",
    tags: ["Grafana", "Prometheus", "SLO"],
    type: "observability",
    githubUrl: "https://github.com/youruser/observability-grafana",
    codeSnippet: `groups:
- name: availability
  rules:
  - alert: HighErrorRate
    expr: rate(http_requests_total{status=~"5.."}[5m]) / rate(http_requests_total[5m]) > 0.05
    for: 10m
    labels:
      severity: page
    annotations:
      summary: "Error rate > 5%"
      description: "Revisar despliegue reciente y logs."`,
  }
];

export default projects;
